# Night House — Android horror prototype

Original first-person stealth-horror prototype inspired by early survival-horror gameplay. It does not contain Granny's copyrighted game files, models, audio, or map.

## Cloud Android build

A GitHub Actions workflow is included to attempt a cloud APK export.

1. Create an empty GitHub repository.
2. Upload the contents of this project folder to that repository.
3. Open **Actions**, enable workflows if prompted, select **Build Android APK**, then press **Run workflow**.
4. When the run finishes, download the `NightHouse-Android-APK` artifact.
5. Extract that downloaded artifact on your phone and tap the APK to install. Android may ask you to allow installs from that source.

This is an unsigned debug APK for testing, not a Play Store release. The cloud build depends on the Godot CI image's Android SDK and export-template setup; it may need maintenance if that image changes.

## Controls

- Touch: drag the left side to move; drag the right side to look.
- Tap USE to interact, HIDE to hide, and NOISE to make a noise.
- Desktop testing: WASD to move; hold right mouse and move to look.

## Prototype status

Includes a small connected house, three collectible keys, a locked exit, a basic patrolling/chasing stalker, touch controls, and simple placeholder 3D art. It is an early prototype, not a finished release.
