extends CanvasLayer

var main_ref
var player
var message_label
var objective_label
var joystick_origin := Vector2.ZERO
var joystick_touch := -1
var look_touch := -1
var last_look := Vector2.ZERO
var joystick_value := Vector2.ZERO
var end_panel: Control

func _ready():
    await get_tree().process_frame
    player = main_ref.player
    _make_ui()

func _make_ui():
    var root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)

    message_label = Label.new()
    message_label.position = Vector2(20,18)
    message_label.size = Vector2(900,50)
    message_label.add_theme_font_size_override("font_size",22)
    message_label.add_theme_color_override("font_color",Color(0.95,0.88,0.72))
    root.add_child(message_label)

    objective_label = Label.new()
    objective_label.position = Vector2(20,58)
    objective_label.add_theme_font_size_override("font_size",18)
    objective_label.add_theme_color_override("font_color",Color(0.85,0.82,0.75))
    root.add_child(objective_label)

    _button(root,"USE",Vector2(-150,-145),Vector2(112,70),"use")
    _button(root,"HIDE",Vector2(-275,-65),Vector2(112,70),"hide")
    _button(root,"NOISE",Vector2(-150,-65),Vector2(112,70),"noise")
    _button(root,"RESTART",Vector2(20,-70),Vector2(130,55),"restart")

    var hint = Label.new()
    hint.text = "Left thumb: move     Right side: look"
    hint.position = Vector2(20,-38)
    hint.add_theme_font_size_override("font_size",15)
    hint.add_theme_color_override("font_color",Color(0.7,0.7,0.7,0.8))
    root.add_child(hint)

func _button(root, text_value, offset, size_value, action):
    var b = Button.new()
    b.text = text_value
    b.size = size_value
    b.anchor_left = 1
    b.anchor_right = 1
    b.anchor_top = 1
    b.anchor_bottom = 1
    b.position = offset
    b.add_theme_font_size_override("font_size",17)
    b.modulate = Color(0.78,0.75,0.69,0.85)
    b.pressed.connect(func(): _act(action))
    root.add_child(b)

func _act(action):
    if not player:
        player = main_ref.player
    match action:
        "use": player.do_interact()
        "hide": player.toggle_hide()
        "noise": player.make_noise()
        "restart": main_ref.restart()

func _input(event):
    if not player:
        return
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < get_viewport().get_visible_rect().size.x * 0.42 and joystick_touch == -1:
                joystick_touch = event.index
                joystick_origin = event.position
                _set_joystick(Vector2.ZERO)
            elif look_touch == -1:
                look_touch = event.index
                last_look = event.position
        else:
            if event.index == joystick_touch:
                joystick_touch = -1
                _set_joystick(Vector2.ZERO)
            if event.index == look_touch:
                look_touch = -1
    elif event is InputEventScreenDrag:
        if event.index == joystick_touch:
            var v = (event.position - joystick_origin) / 75.0
            _set_joystick(v.limit_length(1.0))
        elif event.index == look_touch:
            player.add_look_input(event.relative)
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        player.add_look_input(event.relative)

func _set_joystick(v):
    player.set_move_input(v)

func set_message(t):
    if is_instance_valid(message_label):
        message_label.text = t

func show_end(_won):
    pass
