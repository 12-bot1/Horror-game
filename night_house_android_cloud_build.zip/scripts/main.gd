extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const ENEMY_SCRIPT = preload("res://scripts/enemy.gd")
const UI_SCRIPT = preload("res://scripts/mobile_ui.gd")

var player
var enemy
var ui
var keys := 0
var key_total := 3
var exit_door
var message_label
var game_over := false
var win := false

func _ready():
    _build_world()
    _spawn_player()
    _spawn_enemy()
    _build_ui()
    _say("Find 3 keys and escape. Stay quiet.")

func _process(_delta):
    if game_over or win:
        return
    if enemy and player:
        enemy.player_ref = player
    if player and player.has_method("set_objective"):
        player.set_objective("Keys: %d / %d" % [keys, key_total])

func _build_world():
    var env = WorldEnvironment.new()
    var environment = Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color(0.012, 0.016, 0.023)
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.35, 0.39, 0.48)
    environment.ambient_light_energy = 0.35
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = environment
    add_child(env)

    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 0.22
    sun.shadow_enabled = true
    add_child(sun)

    # Main house: connected rooms and narrow hallways.
    _box("Ground", Vector3(0, -0.2, 0), Vector3(24, 0.4, 24), Color(0.16,0.14,0.13))
    # Outer walls, with a front opening.
    _wall(Vector3(-12, 1.5, 0), Vector3(0.4, 3, 24))
    _wall(Vector3(12, 1.5, 0), Vector3(0.4, 3, 24))
    _wall(Vector3(0, 1.5, -12), Vector3(24, 3, 0.4))
    _wall(Vector3(-4.5, 1.5, 12), Vector3(15, 3, 0.4))
    _wall(Vector3(10.5, 1.5, 12), Vector3(3, 3, 0.4))
    # Interior partitions; door-sized gaps connect the rooms.
    _wall(Vector3(-4, 1.5, -7), Vector3(0.3, 3, 10))
    _wall(Vector3(4, 1.5, -7), Vector3(0.3, 3, 10))
    _wall(Vector3(-4, 1.5, 4), Vector3(0.3, 3, 7))
    _wall(Vector3(4, 1.5, 4), Vector3(0.3, 3, 7))
    _wall(Vector3(0, 1.5, 0), Vector3(7.7, 3, 0.3))
    _wall(Vector3(-8, 1.5, 1), Vector3(7.5, 3, 0.3))
    _wall(Vector3(8, 1.5, 1), Vector3(7.5, 3, 0.3))

    # Ceiling beams and furniture silhouettes.
    for x in [-8, -4, 0, 4, 8]:
        _box("CeilingBeam", Vector3(x, 2.95, 0), Vector3(0.16,0.12,23), Color(0.07,0.06,0.055))
    _box("DiningTable", Vector3(-8,0.75,-7), Vector3(3.2,0.18,1.8), Color(0.19,0.10,0.06))
    _box("TableLeg", Vector3(-9.3,0.35,-7.6), Vector3(0.15,0.7,0.15), Color(0.08,0.05,0.035))
    _box("TableLeg", Vector3(-6.7,0.35,-7.6), Vector3(0.15,0.7,0.15), Color(0.08,0.05,0.035))
    _box("Bed", Vector3(8,0.55,-7), Vector3(3.8,0.7,2.4), Color(0.20,0.16,0.14))
    _box("Mattress", Vector3(8,0.95,-7), Vector3(3.6,0.18,2.2), Color(0.38,0.36,0.33))
    _box("Wardrobe", Vector3(-8,1.1,7), Vector3(2.2,2.2,1.1), Color(0.10,0.065,0.045))
    _box("Cabinet", Vector3(8,0.7,7), Vector3(2.3,1.4,0.8), Color(0.12,0.08,0.06))

    _make_key(Vector3(-8,1.05,-7), "Brass key")
    _make_key(Vector3(8,1.2,-7), "Rusty key")
    _make_key(Vector3(8,1.0,7), "Small key")
    exit_door = _box("ExitDoor", Vector3(4,1.4,11.72), Vector3(2.6,2.8,0.22), Color(0.09,0.045,0.025))
    exit_door.set_meta("exit_door", true)
    exit_door.set_meta("interactable", true)
    exit_door.set_meta("hint", "Front door — needs 3 keys")
    _make_lamp(Vector3(0,2.65,0))
    _make_lamp(Vector3(-8,2.65,-7))
    _make_lamp(Vector3(8,2.65,7))

func _box(n, pos, size, color):
    var body = StaticBody3D.new()
    body.name = n
    body.position = pos
    var mesh = MeshInstance3D.new()
    var box = BoxMesh.new()
    box.size = size
    mesh.mesh = box
    var mat = StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.9
    mesh.material_override = mat
    body.add_child(mesh)
    var shape = CollisionShape3D.new()
    var collision = BoxShape3D.new()
    collision.size = size
    shape.shape = collision
    body.add_child(shape)
    add_child(body)
    return body

func _wall(pos, size):
    return _box("Wall", pos, size, Color(0.12,0.105,0.095))

func _make_lamp(pos):
    var light = OmniLight3D.new()
    light.position = pos
    light.light_color = Color(1.0,0.72,0.43)
    light.light_energy = 0.65
    light.omni_range = 6.5
    light.shadow_enabled = true
    add_child(light)

func _make_key(pos, label):
    var area = Area3D.new()
    area.position = pos
    area.set_meta("interactable", true)
    area.set_meta("is_key", true)
    area.set_meta("hint", "Pick up " + label)
    var mesh = MeshInstance3D.new()
    var m = TorusMesh.new()
    m.inner_radius = 0.07
    m.outer_radius = 0.13
    mesh.mesh = m
    mesh.rotation_degrees.x = 90
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.9,0.62,0.16)
    mat.metallic = 0.8
    mesh.material_override = mat
    area.add_child(mesh)
    var cs = CollisionShape3D.new()
    var sphere = SphereShape3D.new()
    sphere.radius = 0.55
    cs.shape = sphere
    area.add_child(cs)
    area.set_meta("key_label", label)
    add_child(area)

func _spawn_player():
    player = CharacterBody3D.new()
    player.name = "Player"
    player.set_script(PLAYER_SCRIPT)
    player.position = Vector3(0,0.2,9)
    add_child(player)
    player.main_ref = self

func _spawn_enemy():
    enemy = CharacterBody3D.new()
    enemy.name = "GrannyLikeStalker"
    enemy.set_script(ENEMY_SCRIPT)
    enemy.position = Vector3(0,0.2,-8)
    add_child(enemy)
    enemy.player_ref = player

func _build_ui():
    ui = CanvasLayer.new()
    ui.set_script(UI_SCRIPT)
    add_child(ui)
    ui.main_ref = self

func interact(target):
    if not is_instance_valid(target):
        return
    if target.has_meta("is_key") and target.get_meta("is_key"):
        keys += 1
        _say("Key collected! (%d/%d)" % [keys,key_total])
        target.queue_free()
        return
    if target.has_meta("exit_door"):
        if keys >= key_total:
            win = true
            _say("YOU ESCAPED!  Tap restart to play again.")
            ui.show_end(true)
        else:
            _say("The door is locked. Find all 3 keys.")
        return
    if target == enemy:
        _say("Something is too close!")

func caught():
    if game_over or win:
        return
    game_over = true
    _say("CAUGHT!  Tap restart to try again.")
    ui.show_end(false)

func restart():
    get_tree().reload_current_scene()

func _say(t):
    if ui:
        ui.set_message(t)
