extends CharacterBody3D

var player_ref
var speed := 2.35
var gravity := 18.0
var alert := 0.0
var last_known := Vector3.ZERO
var patrol_angle := 0.0
var body_mesh: MeshInstance3D

func _ready():
    var shape = CollisionShape3D.new()
    var capsule = CapsuleShape3D.new()
    capsule.radius = 0.42
    capsule.height = 1.8
    shape.shape = capsule
    shape.position.y = 0.9
    add_child(shape)

    body_mesh = MeshInstance3D.new()
    var mesh = CapsuleMesh.new()
    mesh.radius = 0.42
    mesh.height = 1.8
    body_mesh.mesh = mesh
    body_mesh.position.y = 0.9
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.36,0.32,0.29)
    mat.roughness = 1.0
    body_mesh.material_override = mat
    add_child(body_mesh)

    var head = MeshInstance3D.new()
    var hm = SphereMesh.new()
    hm.radius = 0.34
    hm.height = 0.68
    head.mesh = hm
    head.position.y = 1.95
    head.material_override = mat
    add_child(head)

func _physics_process(delta):
    if not player_ref or player_ref.hidden:
        _patrol(delta)
        return
    var dist = global_position.distance_to(player_ref.global_position)
    var sees = dist < 9.0
    if sees:
        alert = min(alert + delta * 1.8, 1.0)
        last_known = player_ref.global_position
    else:
        alert = max(alert - delta * 0.2, 0.0)
    if alert > 0.1:
        var direction = (last_known - global_position)
        direction.y = 0
        if direction.length() > 0.25:
            velocity.x = direction.normalized().x * speed * (1.0 + alert * 0.35)
            velocity.z = direction.normalized().z * speed * (1.0 + alert * 0.35)
            look_at(Vector3(last_known.x, global_position.y, last_known.z), Vector3.UP)
    else:
        _patrol(delta)
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0
    move_and_slide()
    if dist < 1.15 and not player_ref.hidden and alert > 0.2:
        get_parent().caught()

func _patrol(delta):
    patrol_angle += delta * 0.45
    var target = Vector3(sin(patrol_angle)*4.0, global_position.y, -6 + cos(patrol_angle)*3.0)
    var dir = target - global_position
    dir.y = 0
    if dir.length() > 0.3:
        velocity.x = dir.normalized().x * speed * 0.45
        velocity.z = dir.normalized().z * speed * 0.45
        look_at(Vector3(target.x,global_position.y,target.z), Vector3.UP)
    else:
        velocity.x = move_toward(velocity.x,0,delta*3)
        velocity.z = move_toward(velocity.z,0,delta*3)

func hear_noise(pos):
    last_known = pos
    alert = 1.0
