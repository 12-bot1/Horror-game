extends CharacterBody3D

var main_ref
var camera: Camera3D
var speed := 4.2
var gravity := 18.0
var look_sensitivity := 0.0025
var yaw := 0.0
var pitch := 0.0
var joystick := Vector2.ZERO
var look_delta := Vector2.ZERO
var hidden := false
var objective := "Keys: 0 / 3"
var interact_target = null

func _ready():
    var col = CollisionShape3D.new()
    var capsule = CapsuleShape3D.new()
    capsule.radius = 0.32
    capsule.height = 1.65
    col.shape = capsule
    col.position.y = 0.83
    add_child(col)
    camera = Camera3D.new()
    camera.position.y = 1.48
    camera.current = true
    add_child(camera)
    var lamp = SpotLight3D.new()
    lamp.position = Vector3(0,0,-0.15)
    lamp.rotation_degrees.x = -5
    lamp.light_energy = 1.3
    lamp.spot_range = 13
    lamp.spot_angle = 42
    camera.add_child(lamp)

func _physics_process(delta):
    if hidden:
        velocity = Vector3.ZERO
        return
    var input = joystick
    if Input.is_key_pressed(KEY_W): input.y -= 1
    if Input.is_key_pressed(KEY_S): input.y += 1
    if Input.is_key_pressed(KEY_A): input.x -= 1
    if Input.is_key_pressed(KEY_D): input.x += 1
    input = input.limit_length(1.0)
    yaw -= look_delta.x * look_sensitivity
    pitch = clamp(pitch - look_delta.y * look_sensitivity, -1.15, 1.15)
    look_delta = Vector2.ZERO
    rotation.y = yaw
    camera.rotation.x = pitch
    var direction = (transform.basis * Vector3(input.x,0,input.y)).normalized()
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0
    move_and_slide()
    _find_interactable()

func _find_interactable():
    interact_target = null
    var space = get_world_3d().direct_space_state
    var from = camera.global_position
    var to = from + -camera.global_transform.basis.z * 2.7
    var query = PhysicsRayQueryParameters3D.create(from,to)
    query.exclude = [self]
    query.collide_with_areas = true
    var hit = space.intersect_ray(query)
    if hit and hit.collider:
        var obj = hit.collider
        if obj.has_meta("interactable"):
            interact_target = obj
    # Nearby pickup areas are also interactable.
    if not interact_target:
        for node in get_tree().get_nodes_in_group("pickup"):
            pass

func do_interact():
    if interact_target and main_ref:
        main_ref.interact(interact_target)
    elif main_ref:
        main_ref._say("Nothing to use here.")

func set_objective(text):
    objective = text

func set_move_input(v):
    joystick = v

func add_look_input(v):
    look_delta += v

func toggle_hide():
    hidden = not hidden
    main_ref._say("Hiding..." if hidden else "You step out of hiding.")
    visible = not hidden
    camera.current = not hidden

func make_noise():
    if main_ref and main_ref.enemy:
        main_ref.enemy.hear_noise(global_position)
